
package examengraficabarras;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class ExamenGraficaBarras extends JPanel {
      
    @Override public void paint(Graphics g){
        super.paint(g);
        Graphics2D misgraficos = (Graphics2D) g;
        int basegrafica = 360;
        misgraficos.drawLine(10, 10, 10, 360);                      // eje vertical
        misgraficos.drawLine(10, basegrafica, 760, basegrafica);    // eje horizontal
        // int[] barras = new int []{200,300,100,200,100,200,50,200};
        int[] barras = new int[24];
        /////////////////// EN PRIMER LUGAR ME CONECTO A LA BASE DE DATOS Y SACO DATOS /////
        String url = "jdbc:sqlite:C:\\Users\\gonag\\OneDrive\\Documentos\\GitHub\\ExamenProgramacion\\registros.db";
        Connection conn = null;
        
        try{
           String sql = "SELECT * FROM horasexamen2";
           conn = DriverManager.getConnection(url);
           Statement stmt = conn.createStatement();
           ResultSet rs = stmt.executeQuery(sql);
           int contador = 0;
            while (rs.next()){
                   System.out.println(
                   rs.getInt("numero de visitas2") + "\t" +
                   rs.getString("hora del dia"));
             ////////////////////////////// COJO LOS DATOS DE LA BASE DE DATOS Y LOS METO EN UNA MATRIZ      
            barras[contador] = Integer.parseInt(rs.getString("numero de visitas2"))/10;
            contador++;
            }

        } catch (SQLException e){
        System.out.println(e.getMessage());}
                 
       ////////////// PINTO LOS DATOS DE LA MATRIZ EN UNA GRAFICA
            for (int i = 0;i<barras.length;i++){
        // int randomNum = ThreadLocalRandom.current().nextInt(10,300+1);
            int randomNum = barras[i];
        misgraficos.fillRect(i*30+20, basegrafica-randomNum, 20, randomNum);} // Dibujo de una primera barra
    }

    public static void main(String[] args) {
        // TODO code application logic here
        JFrame marco = new JFrame("grafica");
        ExamenGraficaBarras mimarco = new ExamenGraficaBarras();
        marco.add(mimarco);
        marco.setSize(800,420);
        marco.setVisible(true);
        marco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
    }
}
