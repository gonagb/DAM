
package examenirpf;

public class ExamenIRPF {

    public static void main(String[] args) {
        // En primer lugar, declaro variables
        float iva = 21;
        float base = 1000;
        float irpf = 15;
        // Declaro las operaciones como variables
        float ivacalculado;
        float irpfcalculado;
        float subtotal;
        float importeneto;
        // Ahora realico los calculos realizando operaciones con las variables
        // Calcula el iva
        irpfcalculado = base*(irpf/100);
        subtotal = base - irpfcalculado;
        ivacalculado = subtotal*(iva/100);
        importeneto = subtotal+ivacalculado;
        // El programa retorna algo
        System.out.println("El % de IRPF a retener es de "+irpfcalculado);
        System.out.println("El subtotal es "+subtotal);        
        System.out.println("El iva de la factura es igual "+ivacalculado);
        System.out.println("El total de la factura es de "+importeneto);
    }
    
}
