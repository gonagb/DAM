fun main(){
    val numero = 33

    val decimales = 4.56

    val letra = "g"

    val booleano = true

    val cadena = "Hola si yo buenas tardes"
}