fun main(){
    println(saluda5("Gonzalo","Aguirre Boix"))
}

fun saluda5(nombre:String,apellidos:String):String{
    return "Hola! $nombre $apellidos , te has perdido? que haces aquí?"
}