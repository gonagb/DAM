fun main(){
    // Esto es un comentario

    /*
       Esto es un comentario multilinea
        (c) 2024 - Gonzalo Aguirre Boix
     */
}