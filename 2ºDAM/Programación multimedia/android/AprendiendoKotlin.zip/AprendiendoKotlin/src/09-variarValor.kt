fun main(){
    var nombre = "Goncho"
    println(nombre)
    nombre = "JV"
    println(nombre)
}