fun main(){
    var edad:Int = 27
    // Menor que
    println(4<3)
    // Mayor que
    println(4>3)
    // Menor o igual
    println(4<=3)
    // Mayor o igual
    println(4>=3)
    // Igual igual
    println(4==3)
    // No es igual
    println(4!=3)

}