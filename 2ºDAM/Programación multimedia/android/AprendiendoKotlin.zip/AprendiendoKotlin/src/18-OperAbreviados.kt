fun main(){
    var edad:Int = 27
    println("Mi edad es de: "+edad)
    edad += 3
    println("Mi edad es de: "+edad)
    edad -= 3
    println("Mi edad es de: "+edad)
    edad *= 3
    println("Mi edad es de: "+edad)
    edad /= 3
    println("Mi edad es de: "+edad)
}