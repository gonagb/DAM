fun main(){
    val nombres = arrayOf("Goncho","JV","Kristina","Kevin")
    println(nombres)

    println(nombres[0])

    nombres[1] = "Gonzalo"

    val longitud = nombres.size

    println("La longitud es: $longitud")

}