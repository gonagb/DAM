fun main(){
    val numero:Int = 33

    val decimales:Double = 4.56

    val letra:Char = 'g'

    val booleano:Boolean = true

    val cadena:String = "Hola si yo buenas tardes"
}