fun main(){
    val edad:Int = 27
    if(edad < 30){
        println("Soy joven")
    }
}