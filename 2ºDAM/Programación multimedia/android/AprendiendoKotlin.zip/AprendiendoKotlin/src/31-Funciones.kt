fun main(){
    
}

fun saluda(){
    println("Hola yo te saludo")
}

// Por mucho que cree una funcion, si no la llamo no va