fun main(){
    print("Hola ")
    print("Que tal? ")
    print("Que te cuentas Goncho?")
}