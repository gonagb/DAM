fun main(){
    var nombre = "Goncho"
    println(nombre)
}