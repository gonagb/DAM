fun main(){
    var edad:Int = 27
    println("Mi edad es de: "+edad)
    // Incremento
    edad++
    println("Mi edad es de: "+edad)
    // Decremento
    edad--
    println("Mi edad es de: "+edad)
}