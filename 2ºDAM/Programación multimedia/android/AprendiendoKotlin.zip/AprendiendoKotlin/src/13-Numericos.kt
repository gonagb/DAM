fun main(){
    // Tipos de Datos : enteros
    val edad:Byte = 27
    val altura:Short = 184
    val edad2:Int = 47
    val numero_grande:Long = 556418164545L

    // Tipos de Datos: decimales
    val PI:Float = 3.1416F
    val PI2:Double = 3.1415926
    val numero_muy_grande:Double = 27E10

}