fun main(){
    saluda3("Goncho")
}

fun saluda3(nombre:String){
    println("Hola! $nombre Que tal?")
}