fun main(){
    // Esto es un comentario
    println("y esto NO es un comentario")
}