fun main(){
    saluda4("Gonzalo","Aguirre Boix")
}

fun saluda4(nombre:String,apellidos:String){
    println("Hola! $nombre $apellidos , te has perdido? que haces aquí?")
}