fun main(){
    val rango = 0..100
    for(numero in rango){
        println("Estoy en el numero: $numero")
    }
}