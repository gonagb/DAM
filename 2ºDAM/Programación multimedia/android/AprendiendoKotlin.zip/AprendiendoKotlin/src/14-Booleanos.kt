fun main(){
    val calvo:Boolean = false
    val moreno:Boolean = true
    println(calvo)
    println(moreno)

}