fun main(){
    val edad:Int = 31
    if(edad < 30) {
        println("Soy joven")
    }else{
        println("Ya no soy joven")
    }
}