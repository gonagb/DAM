fun main(){
    // Suma
    println(4+3)
    // Resta
    println(4-3)
    // Multiplicacion
    println(4*3)
    // Division
    println(4/3)
    // Porcentaje
    println(4%3)
}