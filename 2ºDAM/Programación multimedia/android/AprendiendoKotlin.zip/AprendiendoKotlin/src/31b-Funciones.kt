fun main(){
    saluda2()
}

fun saluda2(){
    println("Hola yo te saludo")
}

// Aqui hemos llamado a la funcion