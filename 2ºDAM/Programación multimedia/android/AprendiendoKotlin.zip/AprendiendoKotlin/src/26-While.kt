fun main(){
    val dia = 1
    while(dia < 31){
        println("Hoy es el dia nº $dia del mes")
    }
}