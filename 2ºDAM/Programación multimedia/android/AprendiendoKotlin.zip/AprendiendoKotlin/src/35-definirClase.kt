fun main(){
    println(saluda5("Gonzalo","Aguirre Boix"))
}

class Persona{
    var nombre :String = ""
    var apellidos:String = ""
    var edad:Int = 0
}