fun main(){
    val letra:Char = 'g'
    val nombre:String = "Goncho"

}