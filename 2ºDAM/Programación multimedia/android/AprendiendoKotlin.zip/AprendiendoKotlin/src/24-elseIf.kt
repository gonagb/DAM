fun main(){
    val edad:Int = 27
    if(edad < 10) {
        println("Soy un crío")
    }else if(edad >=10 && edad < 30){
        println("Soy joven")
    }else if(edad >=30 && edad < 70){
        println("Ya no soy joven")
    }else{
        println("Soy un senyor")
    }
}