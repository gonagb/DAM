fun main(){
    val persona_1 = Persona3("Gonzalo","Aguirre Boix",27)
    val persona_2 = Persona3("Jose Vicente","Carratala Sanchis",45)
}

class Persona3(nombre:String,apellidos:String,edad:Int)