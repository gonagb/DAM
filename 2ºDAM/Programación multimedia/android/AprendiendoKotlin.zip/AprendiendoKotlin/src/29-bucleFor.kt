fun main(){
    val nombres = arrayOf("Goncho","JV","Kristina","Kevin")
    for(nombre in nombres){
        println(nombre)
    }

}