fun main(){
    // Como en la mayoría de lenguajes:

    println(3 == 3 && 4 == 4 && 5 == 5)
    println(3 == 2 && 4 == 4 && 5 == 5)

    println(3 == 2 || 4 == 4 || 5 == 5)
    println(3 == 2 || 3 == 4 || 5 == 5)
    println(3 == 2 || 3 == 4 || 4 == 5)
}